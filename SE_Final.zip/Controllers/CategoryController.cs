﻿using System.Web.Mvc;

namespace AWE_Agent_WebApp.Controllers
{
    public class CategoryController : Controller
    {
        public ActionResult Apple()
        {
            return View();
        }

        public ActionResult Laptops()
        {
            return View();
        }

        public ActionResult VideoGames()
        {
            return View();
        }

        public ActionResult MajorAppliance()
        {
            return View();
        }

    }
}
