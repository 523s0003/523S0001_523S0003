﻿using System.Web.Mvc;
using AWE_Agent_WebApp.DAL;
using AWE_Agent_WebApp.Models;

namespace AWE_Agent_WebApp.Controllers
{
    public class ProductController : Controller
    {
        ProductDAL dal = new ProductDAL();

        public ActionResult Index()
        {
            var list = dal.GetAll();
            return View(list);
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(Product p)
        {
            if (ModelState.IsValid)
            {
                dal.Insert(p);
                return RedirectToAction("Index");
            }
            return View(p);
        }
    }
}
